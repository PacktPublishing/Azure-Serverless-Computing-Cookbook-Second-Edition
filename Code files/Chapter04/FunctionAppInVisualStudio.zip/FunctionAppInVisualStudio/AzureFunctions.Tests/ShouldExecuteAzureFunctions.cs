using FunctionAppInVisualStudio;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Primitives;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;
using Microsoft.Extensions.Logging;

namespace AzureFunctions.Tests
{
    public class ShouldExecuteAzureFunction
    {
        [Fact]
        public void WithAQueryString()
        {
            var httpRequestMock = new Mock<HttpRequest>();
            var queryStringParams = new Dictionary<String, StringValues>();
            httpRequestMock.Setup(req => req.Query).Returns(new QueryCollection(queryStringParams));
            queryStringParams.Add("name", "Praveen Sreeram");

            var ILoggerMock = new Mock<ILogger>();
            var result = HttpTriggerCSharpFromVS.Run(httpRequestMock.Object, ILoggerMock.Object);
            var resultObject = (OkObjectResult)result;
            Assert.Equal("Automated Build Trigger & Release test by, Praveen Sreeram", resultObject.Value);
        }
    }
}

