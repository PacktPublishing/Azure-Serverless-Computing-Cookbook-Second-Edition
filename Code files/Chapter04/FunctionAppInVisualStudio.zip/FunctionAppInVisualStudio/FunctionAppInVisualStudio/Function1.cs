using System;
using System.IO;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace FunctionAppInVisualStudio
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static void Run([QueueTrigger("myqueue-items", Connection = "StorageConnection")]string myQueueItem, ILogger log, IBinder binder)
        {
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
            using (var emailLogBloboutput = binder.Bind<TextWriter>(new BlobAttribute($"userregistrationemaillogs/{"inputJson.RowKey"}.log")))
            {
               // emailLogBloboutput.WriteLine("emailContent");
            }
        }
    }
}
